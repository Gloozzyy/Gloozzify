﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace gloozzify_setup
{
    /// <summary>
    /// Interaction logic for GloozzifySetup.xaml
    /// </summary>
    public partial class GloozzifySetup : Window
    {
        public GloozzifySetup()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {

        }

        private void Next_Click(object sender, RoutedEventArgs e)
        {
            if (InstallProgress.Visibility == Visibility.Hidden)
            {
                DownloadStartLabel.Visibility = Visibility.Visible;
                EULAStuff.Visibility = Visibility.Hidden;
                InstallProgress.Visibility = Visibility.Visible;
            }
            Color coooolorrr = (Color)ColorConverter.ConvertFromString("#FFFF6868");
            StatusInstallation2.Foreground = new SolidColorBrush(coooolorrr);
        }

        private void Back_Click(object sender, RoutedEventArgs e)
        {
            if (EULAStuff.Visibility == Visibility.Hidden)
            {
                EULAStuff.Visibility = Visibility.Visible;
                InstallProgress.Visibility = Visibility.Hidden;
            }

            Color coooolorrr2 = (Color)ColorConverter.ConvertFromString("#FF5F5F5F");
            StatusInstallation2.Foreground = new SolidColorBrush(coooolorrr2);
        }

        private void StartDownload_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Thread.Sleep(500);
                if (Directory.Exists(Environment.CurrentDirectory + "\\Gloozzify"))
                {
                    Directory.Delete(Environment.CurrentDirectory + "\\Gloozzify", true);
                }
                CheckExists();
                Directory.CreateDirectory(Environment.CurrentDirectory + "\\Gloozzify");
                WebClient webclient1 = new WebClient();
                webclient1.DownloadFile("https://github.com/Gloozzyy/Gloozzify/blob/main/Gloozzify.zip?raw=true", Environment.CurrentDirectory + "\\Gloozzify\\Gloozzify.zip");
                string zipPath = @"Gloozzify\Gloozzify.zip";
                string extractPath = @"Gloozzify\";
                ZipFile.ExtractToDirectory(zipPath, extractPath);
                try
                {
                    File.Delete(Environment.CurrentDirectory + "\\Gloozzify\\Gloozzify.zip");
                }
                catch
                {
                }
                MessageBox.Show("Installation Finished", "Gloozzify");
                Process.Start("explorer.exe", Environment.CurrentDirectory + "\\Gloozzify\\");
                foreach (Process process in Process.GetProcessesByName("gloozzify-setup"))
                {
                    process.Kill();
                }

            }
            catch
            {

            }
        }
        public static void CheckExists()
        {
            if (Directory.Exists("Gloozzify.exe"))
            {
                foreach (Process process in Process.GetProcessesByName("Gloozzify"))
                {
                    process.Kill();
                }
                Directory.Delete("Gloozzify.exe", true);
            }
        }
    }
}
