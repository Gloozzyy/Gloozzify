﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Gloozzify
{
    /// <summary>
    /// Interaction logic for GloozzifyMain.xaml
    /// </summary>
    public partial class GloozzifyMain : Window
    {
        #region Animations
        Storyboard StoryBoard = new Storyboard();
        TimeSpan duration = TimeSpan.FromMilliseconds(900);
        TimeSpan duration2 = TimeSpan.FromMilliseconds(1000);

        private IEasingFunction Smooth
        {
            get;
            set;
        }
       = new QuarticEase
       {
           EasingMode = EasingMode.EaseInOut
       };

        public async void GloozzifyFade(DependencyObject Object)
        {
            Storyboard storyboard = new Storyboard();
            DoubleAnimation FadeIn = new DoubleAnimation()
            {
                From = 0.0,
                To = 1.0,
                Duration = new Duration(duration),
            };
            Storyboard.SetTarget(FadeIn, Object);
            Storyboard.SetTargetProperty(FadeIn, new PropertyPath("Opacity", 1));
            storyboard.Children.Add(FadeIn);
            storyboard.Begin();
            await Task.Delay(1000);
            StoryBoard.Pause();
        }
        public async void GloozzifyFadeOut(DependencyObject Object)
        {
            Storyboard storyboard = new Storyboard();
            DoubleAnimation Fade = new DoubleAnimation()
            {
                From = 1.0,
                To = 0.0,
                Duration = new Duration(duration),
            };
            Storyboard.SetTarget(Fade, Object);
            Storyboard.SetTargetProperty(Fade, new PropertyPath("Opacity", 1));
            storyboard.Children.Add(Fade);
            storyboard.Begin();
            await Task.Delay(1000);
            StoryBoard.Pause();
        }
        public async void GloozzifyObjectShift(DependencyObject Object, Thickness Get, Thickness Set)
        {
            Storyboard storyboard = new Storyboard();
            ThicknessAnimation Animation = new ThicknessAnimation()
            {
                From = Get,
                To = Set,
                Duration = duration2,
                EasingFunction = Smooth,
            };
            Storyboard.SetTarget(Animation, Object);
            Storyboard.SetTargetProperty(Animation, new PropertyPath(MarginProperty));
            storyboard.Children.Add(Animation);
            storyboard.Begin();
            await Task.Delay(1000);
            StoryBoard.Pause();
        }
        #endregion
        MediaPlayer mediaPlayer = new MediaPlayer();
        private DiscordRpc.EventHandlers handlers;
        private DiscordRpc.RichPresence presence;
        bool toggled = false;
        public GloozzifyMain()
        {
            InitializeComponent();

            this.MaxHeight = SystemParameters.MaximizedPrimaryScreenHeight;
            this.MaxWidth = SystemParameters.MaximizedPrimaryScreenWidth;

            this.handlers = default(DiscordRpc.EventHandlers);
            DiscordRpc.Initialize("878486535954137139", ref this.handlers, true, null);
            this.handlers = default(DiscordRpc.EventHandlers);
            DiscordRpc.Initialize("878486535954137139", ref this.handlers, true, null);
            this.presence.details = "Music player [Alpha]";
            this.presence.largeImageKey = "untitled_13_";
            //this.presence.largeImageText = "ViiPer";
            DiscordRpc.UpdatePresence(presence);
        }

        private List<String> Files = new List<string> { };
        private List<String> Paths = new List<string> { };

        public void MP3Timer_Tick(object sender, EventArgs e)
        {
            if (mediaPlayer.Source != null)
            {
                //TimeLabel.Content = String.Format("{0} / {1}", mediaPlayer.Position.ToString(@"mm\:ss"), mediaPlayer.NaturalDuration.TimeSpan.ToString(@"mm\:ss"));
            }
            else
            {
                //TimeLabel.Content = "No file selected...";
            }
        }

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }

        private void RestoreMaximizeButton_Click(object sender, RoutedEventArgs e)
        {
            if (base.WindowState == WindowState.Maximized)
            {
                ResizeMode = ResizeMode.CanResize;
                base.WindowState = WindowState.Normal;
                RestoreMaximizeButton.Content = "\uE922";
            }
            else if (base.WindowState == WindowState.Normal)
            {
                ResizeMode = ResizeMode.NoResize;
                base.WindowState = WindowState.Maximized;
                RestoreMaximizeButton.Content = "\uE923";
            }
        }

        private void MinimizeButton_Click(object sender, RoutedEventArgs e)
        {
            WindowState = WindowState.Minimized;
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Multiselect = true;
            if (ofd.ShowDialog() == true)
            {
                mediaPlayer.Stop();
                for (int i = 0; i < ofd.FileNames.Length; i++)
                {
                    Files.Add(System.IO.Path.GetFileNameWithoutExtension(ofd.FileNames[i]));
                    Paths.Add(ofd.FileNames[i]);

                    Playlist.Items.Add(Files[i]);
                }
            }

            /*
            OpenFileDialog AddSongsDialog = new OpenFileDialog();
            AddSongsDialog.Filter = "MP3 files (*.mp3)|*.mp3|All files (*.*)|*.*";
            AddSongsDialog.Title = "Gloozzify Song Add";
            AddSongsDialog.Multiselect = true;
            if (AddSongsDialog.ShowDialog() == true)
            {
                files = AddSongsDialog.SafeFileNames;
                paths = AddSongsDialog.FileNames;
                for(int i=0; i <=files.Length -1; i++)
                {
                    Playlist.Items.Add(files[i]);
                }
            } */
        }

        private void Play_Click(object sender, RoutedEventArgs e)
        {
            if (mediaPlayer.Source != null)
            {
                DiscordRpc.Shutdown();
                mediaPlayer.Play();
                SongName.Content = Playlist.SelectedItem;
                mediaPlayer.Volume = (double)VolumeSlider.Value;

                Play.Visibility = Visibility.Hidden;
                Pause.Visibility = Visibility.Visible;
            }
            else
            {

            }
        }

        private void Pause_Click(object sender, RoutedEventArgs e)
        {
            mediaPlayer.Pause();
            Play.Visibility = Visibility.Visible;
            Pause.Visibility = Visibility.Hidden;
        }

        private void Restart_Click(object sender, RoutedEventArgs e)
        {
            
        }

        private void SongsButton_Click(object sender, RoutedEventArgs e)
        {
            GloozzifyObjectShift(TabIndicator, TabIndicator.Margin, new Thickness(34, 33, 0, 0));
        }

        private void PlaylistButton_Click(object sender, RoutedEventArgs e)
        {
            GloozzifyObjectShift(TabIndicator, TabIndicator.Margin, new Thickness(86, 33, 0, 0));
        }

        private void Playlist_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try { mediaPlayer.Stop(); } catch { }
            try
            {
                Play.Visibility = Visibility.Visible;
                Pause.Visibility = Visibility.Hidden;
                mediaPlayer.Open(new Uri(Paths[Playlist.SelectedIndex]));
            }
            catch (Exception ex) 
            {
            }
        }

        private void Next_Click(object sender, RoutedEventArgs e)
        {

        }

        private void Logo_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            Process.Start("https://www.youtube.com/c/Gloozzy");
        }

        private void Window_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (Mouse.LeftButton == MouseButtonState.Pressed)
            {
                DragMove();
            }
        }

        private void FoldersButton_Click(object sender, RoutedEventArgs e)
        {
            GloozzifyObjectShift(TabIndicator, TabIndicator.Margin, new Thickness(138, 33, 0, 0));
        }

        private void LoopOff_Click(object sender, RoutedEventArgs e)
        {

        }

        private void LoopOn_Click(object sender, RoutedEventArgs e)
        {

        }

        private void Information_Click(object sender, RoutedEventArgs e)
        {

        }

        private void Volume_Click(object sender, RoutedEventArgs e)
        {
            if (toggled == false)
            {
                GloozzifyObjectShift(Volume, Volume.Margin, new Thickness(0, 24, 158, 24));
                toggled = false;
                GloozzifyObjectShift(VolumeSlider, VolumeSlider.Margin, new Thickness(0, 29, 16, 30));
                toggled = true;
            }
            else
            {
                GloozzifyObjectShift(VolumeSlider, VolumeSlider.Margin, new Thickness(1966, 29, -1176, 30));
                toggled = false;
                GloozzifyObjectShift(Volume, Volume.Margin, new Thickness(0, 0, 24, 24));
            }
        }

        private void VolumeSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            mediaPlayer.Volume = (double)VolumeSlider.Value;
        }

        private void PlaylistCover_Drop(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.FileDrop))
            {
                try
                {
                    string[] files = (string[])e.Data.GetData(DataFormats.FileDrop);
                    var uri = new Uri(files[0]);
                    var image = new BitmapImage(uri);
                    PlaylistCover.Background = new ImageBrush(image);
                }
                catch
                {
                    MessageBox.Show("You can't use that file format!", "Gloozzify");
                }
            }
        }

        private void Playlist_Drop(object sender, DragEventArgs e)
        {
            object data = e.Data.GetData(DataFormats.FileDrop);
            bool flag = data != null;
            if (flag)
            {
                string[] files = data as string[];
                for (int i = 0; i < files.Length; i++)
                {
                    Files.Add(System.IO.Path.GetFileNameWithoutExtension(files[i]));
                    Paths.Add(files[i]);

                    Playlist.Items.Add(files[i]);
                }
            }
        }
    }
}
