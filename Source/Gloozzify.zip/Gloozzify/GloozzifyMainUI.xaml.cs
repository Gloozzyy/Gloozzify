﻿using Microsoft.Win32;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Threading;

namespace Gloozzify
{
    public partial class GloozzifyMainUI : Window
    {
        #region Animations
        Storyboard StoryBoard = new Storyboard();
        TimeSpan duration = TimeSpan.FromMilliseconds(900);
        TimeSpan duration2 = TimeSpan.FromMilliseconds(1000);

        private IEasingFunction Smooth
        {
            get;
            set;
        }
       = new QuarticEase
       {
           EasingMode = EasingMode.EaseInOut
       };

        public async void GloozzifyFade(DependencyObject Object)
        {
            Storyboard storyboard = new Storyboard();
            DoubleAnimation FadeIn = new DoubleAnimation()
            {
                From = 0.0,
                To = 1.0,
                Duration = new Duration(duration),
            };
            Storyboard.SetTarget(FadeIn, Object);
            Storyboard.SetTargetProperty(FadeIn, new PropertyPath("Opacity", 1));
            storyboard.Children.Add(FadeIn);
            storyboard.Begin();
            await Task.Delay(1000);
            StoryBoard.Pause();
        }
        public async void GloozzifyFadeOut(DependencyObject Object)
        {
            Storyboard storyboard = new Storyboard();
            DoubleAnimation Fade = new DoubleAnimation()
            {
                From = 1.0,
                To = 0.0,
                Duration = new Duration(duration),
            };
            Storyboard.SetTarget(Fade, Object);
            Storyboard.SetTargetProperty(Fade, new PropertyPath("Opacity", 1));
            storyboard.Children.Add(Fade);
            storyboard.Begin();
            await Task.Delay(1000);
            StoryBoard.Pause();
        }
        public async void GloozzifyObjectShift(DependencyObject Object, Thickness Get, Thickness Set)
        {
            Storyboard storyboard = new Storyboard();
            ThicknessAnimation Animation = new ThicknessAnimation()
            {
                From = Get,
                To = Set,
                Duration = duration2,
                EasingFunction = Smooth,
            };
            Storyboard.SetTarget(Animation, Object);
            Storyboard.SetTargetProperty(Animation, new PropertyPath(MarginProperty));
            storyboard.Children.Add(Animation);
            storyboard.Begin();
            await Task.Delay(1000);
            StoryBoard.Pause();
        }
        #endregion
        #region Variables
        private List<String> Files = new List<string> { };
        private List<String> Paths = new List<string> { };
        DispatcherTimer SongProgressTimer = new DispatcherTimer();
        #endregion
        #region Bools
        bool menutoggled = false;
        bool RepeatTrackStat = false;
        #endregion
        #region Functions
        public void SaveSettings()
        {
            using (var StreamWriter = new StreamWriter($"{Environment.CurrentDirectory}\\utils\\Settings.json"))
            {
                Data.Settings settings = new Data.Settings
                {
                    RepeatTrack = RepeatTrackStat,
                    Volume = VolumeSlider.Value
                };
                string formattedjson = JsonConvert.SerializeObject(settings, Newtonsoft.Json.Formatting.Indented);
                StreamWriter.Write(formattedjson);
                //var stuffString = JsonConvert.SerializeObject(settings);
                //File.WriteAllText(@".\utils\Settings.json", stuffString);
            }
        }
        public void LoadSettings()
        {
            if (!File.Exists(@".\utils\Settings.json"))
            {
                return;
            }

            var stuffString = File.ReadAllText(@".\utils\Settings.json");
            Data.Settings settings = JsonConvert.DeserializeObject<Data.Settings>(stuffString);
            VolumeSlider.Value = settings.Volume;
            if (settings.RepeatTrack == true)
            {
                Loop.Content = "\uE8ED";
            }
            else if (settings.RepeatTrack == false)
            {
                Loop.Content = "\uE8EE";
            }
        }
        public void ItemAdd(System.Windows.Controls.ListBox ListBox, string Folder, string FileType)
        {
            DirectoryInfo Directory = new DirectoryInfo(Folder);
            FileInfo[] Files = Directory.GetFiles(FileType);
            foreach (FileInfo file in Files)
            {
                ListBox.Items.Add(file.Name);
            }
        }
        #endregion

        private const string DiscordAppID = "878486535954137139";
        DiscordRpc.RichPresence Presence = new DiscordRpc.RichPresence();

        #region Constructor
        public GloozzifyMainUI()
        {
            InitializeComponent();

            var handlers = new DiscordRpc.EventHandlers();
            DiscordRpc.Initialize(DiscordAppID, ref handlers, false, string.Empty);

            Presence.details = "Idling";
            Presence.state = "Music player [Alpha]";
            Presence.largeImageKey = "gloozzify";
            DiscordRpc.UpdatePresence(Presence);

            mediaPlayer.MediaEnded += OnMediaEnded;
            mediaPlayer.MediaOpened += OnMediaOpened;
        }
        #endregion

        #region Buttons
        #region TopButtons
        private void Minimize_Click(object sender, RoutedEventArgs e)
        {
            WindowState = WindowState.Minimized;
        }
        private void Restore_Click(object sender, RoutedEventArgs e)
        {

        }
        private async void CloseWindow_Click(object sender, RoutedEventArgs e)
        {
            mediaPlayer.Stop();
            SaveSettings();
            GloozzifyObjectShift(BottomBorder, BottomBorder.Margin, new Thickness(82, 447, 82, 23));
            GloozzifyFadeOut(BottomBorder);
            await Task.Delay(200);
            GloozzifyFadeOut(RightBorder);
            GloozzifyFadeOut(LeftBorder);
            GloozzifyObjectShift(RightBorder, RightBorder.Margin, new Thickness(421, 46, 380, 65));
            GloozzifyObjectShift(LeftBorder, LeftBorder.Margin, new Thickness(363, 46, 438, 65));
            await Task.Delay(200);
            GloozzifyObjectShift(MainBorder, MainBorder.Margin, new Thickness(340, 24, 341, 43));
            await Task.Delay(1800);
            GloozzifyFadeOut(MainBorder);
            Application.Current.Shutdown();
        }
        #endregion
        #region MenuButtons
        private void HomeButton_Click(object sender, RoutedEventArgs e)
        {
            MainBorder.Background = new SolidColorBrush(Color.FromRgb(64, 64, 64));
        }
        private void YourLibraryButton_Click(object sender, RoutedEventArgs e)
        {

        }
        private void Settings_Click(object sender, RoutedEventArgs e)
        {
            MainBorder.Background = new SolidColorBrush(Color.FromRgb(17, 17, 17));
        }
        private void MenuButton_Click(object sender, RoutedEventArgs e)
        {
            if (menutoggled == false)
            {
                GloozzifyObjectShift(MainBorder, MainBorder.Margin, new Thickness(82, 24, 218, 43));
                menutoggled = true;
            }
            else
            {
                GloozzifyObjectShift(MainBorder, MainBorder.Margin, new Thickness(218, 24, 218, 43));
                menutoggled = false;
            }
        }
        private void LeftClose_Click(object sender, RoutedEventArgs e)
        {//768,46,169,65

        }
        #endregion
        #region MainButtons
        private void Play_Click(object sender, RoutedEventArgs e)
        {
            if (Play.Content.ToString() == "\uF5B0")
            {
                if (mediaPlayer.Source != null)
                {
                    mediaPlayer.Play();
                    Presence.details = "Listening to";
                    Presence.state = "" + Playlist.SelectedItem;
                    Presence.largeImageKey = "gloozzify";
                    DiscordRpc.UpdatePresence(Presence);
                    SongName.Content = Playlist.SelectedItem;
                    SongProgressTimer.Start();
                    Play.Content = "\uF8AE";
                }
            }
            else if (Play.Content.ToString() == "\uF8AE")
            {
                if (mediaPlayer.Source != null)
                {
                    mediaPlayer.Pause();
                    SongName.Content = Playlist.SelectedItem;

                    Presence.details = "Idling";
                    Presence.state = "Music player [Alpha]";
                    Presence.largeImageKey = "gloozzify";
                    DiscordRpc.UpdatePresence(Presence);
                    SongProgressTimer.Stop();
                    Play.Content = "\uF5B0";
                }
                else
                {

                }
            }
            mediaPlayer.Volume = (double)VolumeSlider.Value;

        }

        private void Previous_Click(object sender, RoutedEventArgs e)
        {
            SongProgressTimer.Stop();
            if (Playlist.SelectedIndex < Playlist.Items.Count + 1)
            {
                try
                {
                    Playlist.SelectedIndex = Playlist.SelectedIndex - 1;
                    mediaPlayer.Play();
                    SongName.Content = Playlist.SelectedItem;
                    SongProgressTimer.Start();
                }
                catch
                {

                }
            }
        }

        private void Information_Click(object sender, RoutedEventArgs e)
        {

        }

        private void Next_Click(object sender, RoutedEventArgs e)
        {

            SongProgressTimer.Stop();
            if (Playlist.SelectedIndex < Playlist.Items.Count - 1)
            {
                Playlist.SelectedIndex = Playlist.SelectedIndex + 1;
                mediaPlayer.Play();
                SongName.Content = Playlist.SelectedItem;
                SongProgressTimer.Start();
            }
        }

        private void Loop_Click(object sender, RoutedEventArgs e)
        {
            if (Loop.Content.ToString() == "\uE8ED")
            {
                RepeatTrackStat = false;
                Loop.Content = "\uE8EE";
            }
            else if (Loop.Content.ToString() == "\uE8EE")
            {
                RepeatTrackStat = true;
                Loop.Content = "\uE8ED";
            }
        }
        #endregion
        #region Sliders
        private void VolumeSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            mediaPlayer.Volume = (double)VolumeSlider.Value;
        }

        private void SongProgress_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            mediaPlayer.Position = TimeSpan.FromSeconds(SongProgress.Value);
        }
        #endregion
        #endregion
        #region Playlist
        private void PlaylistCover_Drop(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.FileDrop))
            {
                try
                {
                    string[] files = (string[])e.Data.GetData(DataFormats.FileDrop);
                    var uri = new Uri(files[0]);
                    var image = new BitmapImage(uri);
                    PlaylistCover.Background = new ImageBrush(image);
                }
                catch
                {
                    MessageBox.Show("You can't use that file format!", "Gloozzify");
                }
            }
        }
        private void Playlist_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                Play.Content = "\uF5B0";
                mediaPlayer.Open(new Uri(Paths[Playlist.SelectedIndex]));
            }
            catch
            {
            }
        }

        private void AddSong_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog songselect = new OpenFileDialog();
            songselect.Filter = "MP3 Files (*.mp3)|*.mp3|All files (*.*)|*.*";
            songselect.Title = "Gloozzify - Song Selector";
            songselect.Multiselect = true;
            if (songselect.ShowDialog() == true)
            {
                for (int i = 0; i < songselect.FileNames.Length; i++)
                {
                    Files.Add(System.IO.Path.GetFileNameWithoutExtension(songselect.FileNames[i]));
                    Paths.Add(songselect.FileNames[i]);

                    Playlist.Items.Add(System.IO.Path.GetFileNameWithoutExtension(songselect.FileNames[i]));
                }
            }
        }
        private void Playlist_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (Play.Content.ToString() == "\uE768")
            {
                if (mediaPlayer.Source != null)
                {
                    mediaPlayer.Play();
                    Presence.details = "Listening to " + Playlist.SelectedItem;
                    Presence.state = "Artists - ";
                    Presence.largeImageKey = "gloozzify";
                    DiscordRpc.UpdatePresence(Presence);
                    SongName.Content = Playlist.SelectedItem;
                    SongProgressTimer.Start();
                    Play.Content = "\uE769";
                }
            }
            else if (Play.Content.ToString() == "\uE769")
            {
                if (mediaPlayer.Source != null)
                {
                    mediaPlayer.Pause();
                    SongName.Content = Playlist.SelectedItem;

                    Presence.details = "Idling";
                    Presence.state = "Music player [Alpha]";
                    Presence.largeImageKey = "gloozzify";
                    DiscordRpc.UpdatePresence(Presence);
                    SongProgressTimer.Stop();
                    Play.Content = "\uE768";
                }
                else
                {

                }
            }
            mediaPlayer.Volume = (double)VolumeSlider.Value;
        }
        #endregion
        #region Media Player
        MediaPlayer mediaPlayer = new MediaPlayer();
        private void OnMediaOpened(object sender, EventArgs e)
        {
            SongProgressTimer.Interval = TimeSpan.FromSeconds(1);
            SongProgressTimer.Start();
            SongProgressTimer.Tick += delegate (object send, EventArgs Event)
            {
                SongProgress.Minimum = 0.0;
                SongProgress.Value = mediaPlayer.Position.TotalSeconds;
                SongProgress.Maximum = mediaPlayer.NaturalDuration.TimeSpan.TotalSeconds;
                SongProgressLabel.Content = mediaPlayer.Position.ToString(@"mm\:ss");
                SongDuration.Content = mediaPlayer.NaturalDuration.TimeSpan.ToString(@"mm\:ss");
            };
        }

        private void OnMediaEnded(object sender, EventArgs e)
        {
            if (Loop.Content.ToString() == "\uE8ED")
            {
                mediaPlayer.Position = TimeSpan.Zero;
                mediaPlayer.Play();
            }
            else if (Loop.Content.ToString() == "\uE8EE")
            {
                //SongProgressTimer.Stop();
                if (Playlist.SelectedIndex < Playlist.Items.Count - 1)
                {
                   //SongProgressTimer.Start();
                    Playlist.SelectedIndex = Playlist.SelectedIndex + 1;
                    mediaPlayer.Play();
                    SongName.Content = Playlist.SelectedItem;
                }
                else
                {
                    //SongProgressTimer.Start();
                    Playlist.SelectedIndex = 0;
                    mediaPlayer.Play();
                    SongName.Content = Playlist.SelectedItem;
                }
            }
        }
        #endregion
        #region Window Functions
        private async void Window_Loaded(object sender, RoutedEventArgs e)
        {
            LoadSettings();
            GloozzifyObjectShift(MainBorder, MainBorder.Margin, new Thickness(218, 24, 218, 43));
            await Task.Delay(200);
            GloozzifyObjectShift(RightBorder, RightBorder.Margin, new Thickness(768, 46, 33, 65));
            GloozzifyFade(RightBorder);
            GloozzifyObjectShift(LeftBorder, LeftBorder.Margin, new Thickness(33, 46, 768, 65));
            GloozzifyFade(LeftBorder);
            await Task.Delay(200);
            GloozzifyFade(BottomBorder);
            GloozzifyObjectShift(BottomBorder, BottomBorder.Margin, new Thickness(82, 447, 82, 23));
        }
        private void MainBorder_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            this.DragMove();
        }
        #endregion
    }
}