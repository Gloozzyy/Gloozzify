﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Gloozzify
{
    /// <summary>
    /// Interaction logic for Loader.xaml
    /// </summary>
    public partial class Loader : Window
    {
        #region Animations
        Storyboard StoryBoard = new Storyboard();
        TimeSpan duration = TimeSpan.FromMilliseconds(900);
        TimeSpan duration2 = TimeSpan.FromMilliseconds(1000);

        private IEasingFunction Smooth
        {
            get;
            set;
        }
       = new QuarticEase
       {
           EasingMode = EasingMode.EaseInOut
       };

        public async void GloozzifyFade(DependencyObject Object)
        {
            Storyboard storyboard = new Storyboard();
            DoubleAnimation FadeIn = new DoubleAnimation()
            {
                From = 0.0,
                To = 1.0,
                Duration = new Duration(duration),
            };
            Storyboard.SetTarget(FadeIn, Object);
            Storyboard.SetTargetProperty(FadeIn, new PropertyPath("Opacity", 1));
            storyboard.Children.Add(FadeIn);
            storyboard.Begin();
            await Task.Delay(1000);
            StoryBoard.Pause();
        }
        public async void GloozzifyFadeOut(DependencyObject Object)
        {
            Storyboard storyboard = new Storyboard();
            DoubleAnimation Fade = new DoubleAnimation()
            {
                From = 1.0,
                To = 0.0,
                Duration = new Duration(duration),
            };
            Storyboard.SetTarget(Fade, Object);
            Storyboard.SetTargetProperty(Fade, new PropertyPath("Opacity", 1));
            storyboard.Children.Add(Fade);
            storyboard.Begin();
            await Task.Delay(1000);
            StoryBoard.Pause();
        }
        public async void GloozzifyObjectShift(DependencyObject Object, Thickness Get, Thickness Set)
        {
            Storyboard storyboard = new Storyboard();
            ThicknessAnimation Animation = new ThicknessAnimation()
            {
                From = Get,
                To = Set,
                Duration = duration2,
                EasingFunction = Smooth,
            };
            Storyboard.SetTarget(Animation, Object);
            Storyboard.SetTargetProperty(Animation, new PropertyPath(MarginProperty));
            storyboard.Children.Add(Animation);
            storyboard.Begin();
            await Task.Delay(1000);
            StoryBoard.Pause();
        }
        #endregion

        public Loader()
        {
            InitializeComponent();
        }

        private async void Window_Loaded(object sender, RoutedEventArgs e)
        {
            await Task.Delay(800);
            Status.Content = "Checking version";
            WebClient wc = new WebClient();
            string text = wc.DownloadString("https://raw.githubusercontent.com/Gloozzyy/Gloozzify/main/Utils/Version");
            if (text.Contains("BETA_v1"))
            {
                try
                {
                    Status.Content = "Checking windows version";
                    if (Environment.OSVersion.Version < new Version(6, 2))
                    {
                        if (MessageBox.Show("Windows 7 detected, please upgrade to Windows 10", "Gloozify", MessageBoxButton.OK, MessageBoxImage.Error) == MessageBoxResult.OK)
                        {
                            Application.Current.Shutdown();
                        }
                    }
                    else
                    {
                        if (Properties.Settings.Default.AcceptedPrivacy == "True")
                        {
                            GloozzifyMainUI gloozzify = new GloozzifyMainUI();
                            this.Hide();
                            gloozzify.Show();
                            this.Close();
                        }
                        else
                        {
                            PrivacyPolicy privacygloozzify = new PrivacyPolicy();
                            this.Hide();
                            privacygloozzify.Show();
                            this.Close();
                        }
                    }
                }
                catch
                {
                    if (MessageBox.Show("Failed to get version!", "Gloozify", MessageBoxButton.OK) == MessageBoxResult.OK)
                    {
                        Application.Current.Shutdown();
                    }
                }
            }
            else
            {
                if (MessageBox.Show("Looks like your version of Gloozzify is outdated!, You can download at https://gloozzify.000webhostapp.com/, or run the setup!", "Gloozify") == MessageBoxResult.OK)
                {
                    Application.Current.Shutdown();
                }
            }
        }
    }
}
