﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Gloozzify
{
    /// <summary>
    /// Interaction logic for PrivacyPolicy.xaml
    /// </summary>
    public partial class PrivacyPolicy : Window
    {
        public PrivacyPolicy()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            AvalonText.Text = File.ReadAllText(Environment.CurrentDirectory + "\\utils\\policy.gloozzify");
        }

        private void Accept_Click(object sender, RoutedEventArgs e)
        {
            GloozzifyMainUI gloozzify = new GloozzifyMainUI();
            this.Hide();
            gloozzify.Show();
            this.Close();
            Properties.Settings.Default.AcceptedPrivacy = "True";
            Properties.Settings.Default.Save();
        }

        private void Decline_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
            Properties.Settings.Default.AcceptedPrivacy = "False";
            Properties.Settings.Default.Save();
        }
    }
}
